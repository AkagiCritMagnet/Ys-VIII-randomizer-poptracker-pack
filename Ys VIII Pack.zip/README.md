# Ys-VIII-randomizer---poptracker-pack
This is a pack on poptracker for the Ys VIII randomizer called "Seiren Shuffle".

Poptracker can be downloaded here: https://poptracker.github.io/
To use my pack, click on the green "<>code" and then "download ZIP". In poptracker, create a folder inside the "packs" folder and unzip everything in it. Launch poptracker and here you go!

Seiren Shuffle repository: https://github.com/junglechief87/Seiren-Shuffle-An-Ys-8-Randomizer-

I'm open for suggestions and insight of course. Feel free to talk to me here or on the thread about this randomizer on the Archipelago Discord: https://discord.com/channels/731205301247803413/1260965063397871657


## Credits

Ys VIII: Lacrimosa of Dana is a game developped by Nihon Falcom.

Seiren Shuffle is project in development by junglechief87, ooiale and Ballistixx99. Big thanks to them for their hard work.

I want to also thank ☈ⒶⒹical ടquirrel on Steam for more than half of the map images. That spared me quite some time.